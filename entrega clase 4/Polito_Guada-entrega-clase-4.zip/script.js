// SIMULADOR PAQUETES DE VIAJES

function duracionviaje(diasviaje) {
    if(dias >2 && dias <=5){
        alert ('Opciones de viajes menor a 5 días: Sierra de la Ventana - Córdoba - Iguazú.');
    }else if(dias >5 && dias <=8){
        alert ('Opciones de viajes hasta 8 días: Bariloche y San Martín de los Andes - Mendoza y San Juan - Salta y Jujuy.');
    }else if(dias >8 && dias <=12){
        alert ('Opciones de viajes hasta 12 días: El Calafate y Ushuaia - Río de Janeiro y Búzios - Cartagena y San Andrés.');
    }else if(dias >12 && dias <=16){
        alert ('Opciones de viajes hasta 16 días: Miami y New York - Cuba - Panamá y Costa Rica.');
    }else if (dias >16 && dias <=30){
        alert ('Opciones de viajes hasta 30 días: España y Portugal - Italia y Grecia - India.');
    }else{
        alert ('Lo sentimos no tenemos opciones disponibles con los datos ingresados. Prueba menor a 30 días.');
    }
}

let nombre = prompt ('Ingrese su nombre');
    alert('Hola '+ nombre + ' bienvenido/a al simulador de paquetes de viajes de Triglav!')

let dias = Number(prompt ('¿Qué duración te gustaría que tenga tu viaje? (en días)'))
    


duracionviaje(dias);

