var nombre = prompt('Ingrese aquí su nombre');
console.log("Nombre:" + nombre);

var apellido = prompt('Ingrese aquí su apellido');
console.log("Apellido:" + apellido);

var resultado = nombre + apellido;
alert("Bienvenida/o " + nombre + " " + apellido);

var anio = 2021;

var anionacimiento = prompt('Ingrese aquí su año de nacimiento');
console.log("anionacimiento :" + anionacimiento);

alert("Su edad es " + (anio - anionacimiento));